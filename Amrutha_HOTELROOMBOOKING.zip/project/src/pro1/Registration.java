package pro1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;

public class Registration extends JFrame {

	private JFrame frame;
	private JTextField name;
	private JTextField username;
	private JPasswordField passwordField;
	private JTextField answer;
	private JPasswordField confirmpass;
	private JTextField phonenum;
 static int uid4;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registration window = new Registration(uid4);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Registration(int id) {
		uid4=id;

		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = this;
		frame.setSize(1920,1080);
		frame.getContentPane().setBackground(new Color(169, 169, 169));
		frame.getContentPane().setForeground(Color.BLACK);
		//frame.setBounds(200, 200, 1920, 1080);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel Signup = new JLabel("Book Your Room Now!");
		Signup.setForeground(Color.WHITE);
		Signup.setFont(new Font("Times New Roman", Font.BOLD, 30));
		Signup.setBounds(154, 104, 443, 59);
		frame.getContentPane().add(Signup);

		
		JLabel Name = new JLabel("Name:");
		Name.setForeground(Color.WHITE);
		Name.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		Name.setBounds(131, 236, 53, 25);
		frame.getContentPane().add(Name);
		
		JLabel Username = new JLabel("Username:");
		Username.setForeground(new Color(255, 255, 255));
		Username.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		Username.setBounds(131, 283, 76, 14);
		frame.getContentPane().add(Username);
		
		JLabel Password = new JLabel("Password:");
		Password.setForeground(Color.WHITE);
		Password.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		Password.setBounds(131, 320, 76, 14);
		frame.getContentPane().add(Password);
		
		JLabel Sequrityques = new JLabel("Security Question:");
		Sequrityques.setForeground(Color.WHITE);
		Sequrityques.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		Sequrityques.setBounds(131, 436, 132, 14);
		frame.getContentPane().add(Sequrityques);
		
		JLabel Answer = new JLabel("Answer:");
		Answer.setForeground(Color.WHITE);
		Answer.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		Answer.setBounds(131, 478, 76, 14);
		frame.getContentPane().add(Answer);
		
		name = new JTextField();
		name.setBounds(422, 239, 175, 20);
		frame.getContentPane().add(name);
		name.setColumns(10);
		
		username = new JTextField();
		username.setBounds(422, 281, 175, 20);
		frame.getContentPane().add(username);
		username.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(422, 318, 175, 20);
		frame.getContentPane().add(passwordField);
		passwordField.setColumns(10);
		
		answer = new JTextField();
		answer.setBounds(422, 476, 175, 20);
		frame.getContentPane().add(answer);
		answer.setColumns(10);
		String[] s1= {"Select","What is your fav color?","What is your nick name?","What is your pet's name?"};
		
		JComboBox security = new JComboBox(s1);
		security.setBounds(422, 433, 175, 22);
		frame.getContentPane().add(security);
		
		JLabel Confirmpassword = new JLabel("Confirm Password:");
		Confirmpassword.setForeground(Color.WHITE);
		Confirmpassword.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		Confirmpassword.setBounds(131, 356, 117, 14);
		frame.getContentPane().add(Confirmpassword);
		
		confirmpass = new JPasswordField();
		confirmpass.setBounds(422, 354, 175, 20);
		frame.getContentPane().add(confirmpass);
		
		JLabel Phone = new JLabel("Phone Number:");
		Phone.setForeground(Color.WHITE);
		Phone.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		Phone.setBounds(131, 397, 124, 14);
		frame.getContentPane().add(Phone);
		
		phonenum = new JTextField();
		phonenum.setBounds(422, 395, 175, 20);
		frame.getContentPane().add(phonenum);
		phonenum.setColumns(10);
		
		JButton Next = new JButton("Next");
		Next.setFont(new Font("Tahoma", Font.BOLD, 12));
		Next.setBounds(266, 563, 89, 23);
		frame.getContentPane().add(Next);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Amrutha\\Downloads\\photo-1517840901100-8179e982acb7.jpeg"));
		lblNewLabel.setBounds( -183, -64, 1920, 1080);
		frame.getContentPane().add(lblNewLabel);
		frame.setVisible(true);
		Next.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try 
				{
					
				String pass = passwordField.getText();
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","msc","msc");
					Statement stmt=con.createStatement();
					String query= "select count(userid) from users";
					ResultSet rs=stmt.executeQuery(query);
					rs.next();
					int uid=rs.getInt(1);
					int newuid=uid+1;
					String sql="insert into users values(?,?,?,?,?,?,?)";  
					PreparedStatement ps=con.prepareStatement(sql);  
					ps.setInt(1,newuid);
					ps.setString(2,name.getText());
					ps.setString(3,username.getText());
					ps.setString(4, pass);
					ps.setInt(5,Integer.parseInt(phonenum.getText()));
					ps.setString(6,security.getSelectedItem().toString());
					ps.setString(7,answer.getText());
					try {
						int i=ps.executeUpdate();
						System.out.print(i);
					}
					catch(Exception e2) {
						System.out.print(e2);
					}
					  
				}
				catch(Exception e3) {
					System.out.print(e3);
				}
				try {
					String pass = passwordField.getText();
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","msc","msc");
					Statement stmt=con.createStatement();
					String query= "select max(userid) from users";
					ResultSet rs=stmt.executeQuery(query);
					rs.next();
					new Reservation(rs.getInt(1)).setVisible(true);
					setVisible(false);
				}catch(Exception e6){
					System.out.println(e6);
					
				}
			
			}
			});
		
			}
		
	}

