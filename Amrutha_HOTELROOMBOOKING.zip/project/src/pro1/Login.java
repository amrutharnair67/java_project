package pro1;
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import pro1.Registration;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;

public class Login extends JFrame{

	private JFrame frame;
	private JTextField USERNAME;
	private JPasswordField PASSWORD;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = this;
		frame.setSize(1920,1080);
		frame.setBounds(200, 200, 1003,600);
		frame.getContentPane().setBackground(Color.LIGHT_GRAY);
		frame.getContentPane().setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("Welcome  Please Login!");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 39));
		lblNewLabel.setBounds(347, 57, 502, 60);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("User name:");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblNewLabel_1.setBounds(276, 182, 122, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password:");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 19));
		lblNewLabel_2.setBounds(276, 238, 79, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		USERNAME = new JTextField();
		USERNAME.setBounds(644, 181, 139, 20);
		frame.getContentPane().add(USERNAME);
		USERNAME.setColumns(10);
		
		PASSWORD = new JPasswordField();
		PASSWORD.setBounds(644, 237, 139, 20);
		frame.getContentPane().add(PASSWORD);
		PASSWORD.setColumns(10);
		
		JButton btnNewButton = new JButton("SIGN UP");
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 13));
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setBackground(new Color(240, 248, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Registration obj=new Registration(0);

				obj.setVisible(true);
				setVisible(false);
				
			}
		});
		btnNewButton.setBounds(222, 365, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("SUBMIT");
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnNewButton_1.setForeground(new Color(0, 0, 0));
		btnNewButton_1.setBackground(new Color(240, 248, 255));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","msc","msc");
					Statement stmt=con.createStatement();
					String query1="select * from users where username='"+USERNAME.getText()+"' and password='"+PASSWORD.getText()+"'";
					System.out.println(query1);
					ResultSet rs=stmt.executeQuery(query1);
					if(rs.next())
					{
						frame.setVisible(false);
						new Reservation(rs.getInt(1)).setVisible(true);
						setVisible(false);
					}
					else {
						JOptionPane.showMessageDialog(null, "Login failed");
					}
				}
				catch(Exception e5) {
					System.out.println(e5);
			}	
				
				
				
			}
		});
		btnNewButton_1.setBounds(749, 365, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\Amrutha\\Downloads\\dark_purple_blue_shades_hd_dark_purple-1600x900.jpg"));
		lblNewLabel_3.setBounds(-25, -56, 1603, 1008);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel label = new JLabel("New label");
		label.setBounds(265, 298, 46, 14);
		frame.getContentPane().add(label);
		frame.setBounds(100, 100, 981, 802);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
