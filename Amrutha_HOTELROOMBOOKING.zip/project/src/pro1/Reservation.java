package pro1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Reservation extends JFrame {

	private JFrame frame;
	private JTextField name;
	private JTextField phoneno;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_3;
	private JTextField arrival;
	private JTextField deperture;
	private JButton btnNewButton;
	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_9;
	private JLabel lblNewLabel_10;
	private JLabel lblNewLabel_11;
	private JLabel lblNewLabel_12;
 static int uid4;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reservation window = new Reservation(uid4);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Reservation(int id) {
		
		uid4=id;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = this;
		//frame.setSize(1920, 1080);
		frame.setBounds(375, 100, 724, 599);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Start  your booking...");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel.setForeground(new Color(230, 230, 250));
		lblNewLabel.setBounds(174, 10, 268, 52);
		frame.getContentPane().add(lblNewLabel);
		
		name = new JTextField();
		name.setBounds(230, 163, 137, 20);
		frame.getContentPane().add(name);
		name.setColumns(10);
		
		phoneno = new JTextField();
		phoneno.setForeground(Color.BLACK);
		phoneno.setBounds(230, 217, 137, 20);
		frame.getContentPane().add(phoneno);
		phoneno.setColumns(10);
		
		lblNewLabel_2 = new JLabel("Name:");
		lblNewLabel_2.setForeground(new Color(240, 248, 255));
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_2.setBounds(77, 164, 72, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		lblNewLabel_1 = new JLabel("Phone No:");
		lblNewLabel_1.setForeground(new Color(240, 248, 255));
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(77, 218, 101, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		lblNewLabel_3 = new JLabel("Address");
		lblNewLabel_3.setForeground(new Color(240, 248, 255));
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_3.setBounds(77, 280, 87, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JTextArea address = new JTextArea();
		address.setBounds(213, 277, 154, 59);
		frame.getContentPane().add(address);
		
		JLabel lblNewLabel_5 = new JLabel("Arrival(Date)");
		lblNewLabel_5.setForeground(new Color(230, 230, 250));
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_5.setBounds(77, 381, 139, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Deperture(Date)");
		lblNewLabel_6.setForeground(new Color(230, 230, 250));
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel_6.setBounds(77, 420, 123, 14);
		frame.getContentPane().add(lblNewLabel_6);
		
		arrival = new JTextField();
		arrival.setBounds(230, 380, 137, 20);
		frame.getContentPane().add(arrival);
		arrival.setColumns(10);
		
		deperture = new JTextField();
		deperture.setBounds(230, 419, 137, 20);
		frame.getContentPane().add(deperture);
		deperture.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Choose Your Choice");
		lblNewLabel_7.setForeground(new Color(230, 230, 250));
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_7.setBounds(496, 140, 175, 14);
		frame.getContentPane().add(lblNewLabel_7);
		
String[] s1= {"Room Type","AC-SingleRoom","NON-AC-SingleRoom","AC-DoubleRoom","NON-AC-DoubleRoom"};

		
		JComboBox Roomtype = new JComboBox(s1);
		Roomtype.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		Roomtype.setBounds(496, 162, 175, 22);
		frame.getContentPane().add(Roomtype);
String[] s2= {"Floor","1","2"};

		
		JComboBox Floor = new JComboBox(s2);
		Floor.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		Floor.setBounds(496, 198, 175, 22);
		frame.getContentPane().add(Floor);
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","msc","msc");
			Statement stmt=con.createStatement();
			String query2="select * from users where userid='"+uid4+"'";
			ResultSet rs=stmt.executeQuery(query2);
			if(rs.next())
			{
				name.setText(rs.getString(2));
				phoneno.setText(rs.getString(5));
			}
		}
		catch(Exception e)
		{}
			
		
		btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
			
						//frame.setVisible(false);
						JOptionPane.showMessageDialog(null, "Booked Successfully.");
						
						setVisible(false);
					}
				
				
			
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 11));
		btnNewButton.setBounds(529, 499, 89, 23);
		getContentPane().add(btnNewButton);
		
		lblNewLabel_8 = new JLabel("Payment on deperture time!");
		lblNewLabel_8.setForeground(new Color(230, 230, 250));
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_8.setBounds(511, 355, 160, 17);
		getContentPane().add(lblNewLabel_8);
		
		lblNewLabel_9 = new JLabel("Further Details DM-msccs2205@rajagiri.edu");
		lblNewLabel_9.setForeground(new Color(230, 230, 250));
		lblNewLabel_9.setFont(new Font("Times New Roman", Font.ITALIC, 13));
		lblNewLabel_9.setBounds(424, 383, 247, 14);
		getContentPane().add(lblNewLabel_9);
		
		lblNewLabel_10 = new JLabel(".");
		lblNewLabel_10.setForeground(new Color(230, 230, 250));
		lblNewLabel_10.setIcon(new ImageIcon("C:\\Users\\Amrutha\\Downloads\\blurry-background-g84ocy8o9me148jv.jpg"));
		lblNewLabel_10.setBounds(10, 72, 404, 464);
		getContentPane().add(lblNewLabel_10);
		
		lblNewLabel_11 = new JLabel(".");
		lblNewLabel_11.setIcon(new ImageIcon("C:\\Users\\Amrutha\\Downloads\\photo-1517840901100-8179e982acb7.jpeg"));
		lblNewLabel_11.setBounds(408, 72, 324, 464);
		getContentPane().add(lblNewLabel_11);
		
		lblNewLabel_12 = new JLabel(".");
		lblNewLabel_12.setForeground(new Color(240, 248, 255));
		lblNewLabel_12.setIcon(new ImageIcon("C:\\Users\\Amrutha\\Downloads\\blur-blurred-background-dark-dreary.jpg"));
		lblNewLabel_12.setBounds(10, 0, 722, 81);
		getContentPane().add(lblNewLabel_12);
		
		
		
	}

	


}
